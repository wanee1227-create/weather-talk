const getWeatherBtn = document.getElementById("getWeatherBtn");
const cityInput = document.getElementById("cityInput");
const addFavoriteBtn = document.getElementById("addFavoriteBtn");
const weatherInfo = document.getElementById("weatherInfo");
const favoritesList = document.getElementById("favoritesList");

// 영어 → 한글 변환
const weatherMap = {
  "sunny":"맑음","clear":"맑음","partly cloudy":"구름 조금","cloudy":"흐림",
  "overcast":"흐림","mist":"안개","patchy rain possible":"간헐적 비","patchy snow possible":"간헐적 눈",
  "patchy sleet possible":"간헐적 진눈깨비","patchy freezing drizzle possible":"간헐적 빙결 이슬비",
  "thundery outbreaks possible":"번개 가능","blowing snow":"눈보라","blizzard":"눈보라",
  "fog":"안개","freezing fog":"빙결 안개","patchy light drizzle":"간헐적 이슬비",
  "light drizzle":"이슬비","freezing drizzle":"빙결 이슬비","heavy freezing drizzle":"강한 빙결 이슬비",
  "patchy light rain":"간헐적 약한 비","light rain":"약한 비","moderate rain at times":"가끔 비",
  "moderate rain":"보통 비","heavy rain at times":"가끔 강한 비","heavy rain":"강한 비",
  "light snow":"약한 눈","moderate snow":"보통 눈","heavy snow":"강한 눈",
  "ice pellets":"우박","light sleet":"약한 진눈깨비","moderate or heavy sleet":"보통/강한 진눈깨비",
  "light rain shower":"약한 소나기","moderate or heavy rain shower":"보통/강한 소나기",
  "torrential rain shower":"폭우","light sleet showers":"약한 진눈깨비 소나기",
  "moderate or heavy sleet showers":"보통/강한 진눈깨비 소나기","light snow showers":"약한 눈 소나기",
  "moderate or heavy snow showers":"보통/강한 눈 소나기",
  "light showers of ice pellets":"약한 우박 소나기","moderate or heavy showers of ice pellets":"보통/강한 우박 소나기",
  "patchy light rain with thunder":"약한 비+번개","moderate or heavy rain with thunder":"보통/강한 비+번개",
  "patchy light snow with thunder":"약한 눈+번개","moderate or heavy snow with thunder":"보통/강한 눈+번개"
};

function translateWeather(desc) {
  const key = desc.trim().toLowerCase();
  return weatherMap[key] || "";
}

// 페이지 로드 시 마지막 도시 불러오기 + 즐겨찾기
document.addEventListener("DOMContentLoaded", () => {
  const savedCity = localStorage.getItem("lastCity");
  if(savedCity) {
    cityInput.value = savedCity;
    fetchWeather(savedCity);
  }
  loadFavorites();
});

// 날씨 버튼 클릭
getWeatherBtn.addEventListener("click", () => {
  const city = cityInput.value.trim() || "서울";
  localStorage.setItem("lastCity", city);
  fetchWeather(city);
});

// 즐겨찾기 추가 버튼
addFavoriteBtn.addEventListener("click", () => {
  const city = cityInput.value.trim();
  if(!city) return;

  let favorites = JSON.parse(localStorage.getItem("favorites") || "[]");
  if(!favorites.includes(city)) {
    favorites.push(city);
    localStorage.setItem("favorites", JSON.stringify(favorites));
    loadFavorites();
  }
});

// 즐겨찾기 목록 로드
function loadFavorites() {
  favoritesList.innerHTML = "";
  const favorites = JSON.parse(localStorage.getItem("favorites") || "[]");
  favorites.forEach(city => {
    const btn = document.createElement("div");

    const nameSpan = document.createElement("span");
    nameSpan.textContent = city;
    nameSpan.className = "favoriteCityName";
    nameSpan.addEventListener("click", () => {
      cityInput.value = city;
      localStorage.setItem("lastCity", city);
      fetchWeather(city);
    });

    const delBtn = document.createElement("span");
    delBtn.textContent = "❌";
    delBtn.className = "deleteBtn";
    delBtn.addEventListener("click", () => removeFavorite(city));

    btn.appendChild(nameSpan);
    btn.appendChild(delBtn);
    favoritesList.appendChild(btn);
  });
}

// 즐겨찾기 삭제
function removeFavorite(city) {
  let favorites = JSON.parse(localStorage.getItem("favorites") || "[]");
  favorites = favorites.filter(c => c !== city);
  localStorage.setItem("favorites", JSON.stringify(favorites));
  loadFavorites();
}

// 날씨 불러오기
function fetchWeather(city) {
  // 로딩 표시
  weatherInfo.innerHTML = "<p>🌤️ 날씨 불러오는 중...</p>";

  fetch(`https://wttr.in/${encodeURIComponent(city)}?format=j1`)
    .then(response => response.json())
    .then(data => displayWeather(data, city))
    .catch(err => {
      weatherInfo.innerHTML = "❌ 날씨 정보를 가져올 수 없습니다.";
      console.error(err);
    });
}

// 날씨 표시
function displayWeather(data, city) {
  let html = `<h2>${city} 날씨</h2>`;
  const today = data.current_condition[0];
  const desc = translateWeather(today.weatherDesc[0].value);

  html += `<p>현재: ${today.temp_C}°C | ${desc}</p>`;
  html += `<p>습도: ${today.humidity}% | 바람: ${today.windspeedKmph} km/h</p>`;

  html += `<h3>주간 예보</h3>`;
  data.weather.forEach(day => {
    const dayDesc = translateWeather(day.hourly[0].weatherDesc[0].value);
    html += `
      <div class="dayForecast">
        <div>${day.date}</div>
        <div>${day.maxtempC}°C / ${day.mintempC}°C</div>
        <div>${dayDesc}</div>
      </div>
    `;
  });

  weatherInfo.innerHTML = html;
}

// 정보 버튼 토글
const infoBtn = document.getElementById("infoBtn");
const infoBox = document.getElementById("infoBox");
infoBtn.addEventListener("click", () => {
  infoBox.classList.toggle("visible");
});
